//import { ITEMS_FETCH_DATA_SUCCESS } from './items'
export function controlsFetchDataSuccess(items) {

    return {
        type: 'CONTROLS_FETCH_DATA_SUCCESS',
        controlList: items
    }
}