import { combineReducers } from 'redux'
import controlReducer from './control'
import runReducer from './runReducer'
import tableCellNotes from './tableCellNotes'

export default combineReducers({
    controlReducer, runReducer,
    tableCellNotes
})