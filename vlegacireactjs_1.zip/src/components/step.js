import React from "react"
import stepData from './stepdata.json';
import { connect } from 'react-redux';

import { bindActionCreators } from 'redux';
import Section from "./section";
import { fetchRunSection } from '../containers/run/fetchRunSection';

const groupBy = (items, key) => items.reduce(
    (result, item) =>
        Object.assign(result, { [item[key]]: (result[item[key]] || []).concat(item) }),
    {},
);

class Step extends React.Component {
    /**
     * Here, we define a react lifecycle method that gets executed each time 
     * our component is mounted to the DOM, which is exactly what we want in this case
     */
    componentDidMount() {
        if (!this.props.runSectionList || !(this.props.runSectionList.length > 0)) {
            this.props.fetchData('http://localhost:3004/Data');
        }
    }
    createRenderData = () => {
        let stepGroupData = {};
        let { runSectionList } = this.props;
        if (runSectionList && runSectionList.length > 0)
            stepGroupData = groupBy(runSectionList, 'Type');
        let renderStep = [];
        for (var prop in stepGroupData) {
            if (Object.prototype.hasOwnProperty.call(stepGroupData, prop)) {
                renderStep.push(<div>  <Section key={prop} sectionTitle={prop} sectionData={stepGroupData[prop]} /> <br /></div>);
            }
        }
        return renderStep;
    }
    render() {
        if (this.props.pending) {
            return <div class="col">Loading... {this.props.pending}</div>;
        }
        return (
            <div class="col">
                {this.createRenderData()}
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        runSectionList: state.runReducer.runSectionList,
        error: state.error,
        pending: state.pending
    };
};

const mapDispatchToProps = dispatch => bindActionCreators({
    fetchData: fetchRunSection
}, dispatch)
export default connect(mapStateToProps, mapDispatchToProps)(Step);
