import { itemsIsLoading, itemsHasErrored } from '../../actions/items';
import { controlsFetchDataSuccess } from '../../actions/control';

export function fetchControls(url) {
    return (dispatch) => {
        dispatch(itemsIsLoading(true));
        fetch(url).then(res => res.json())
            .then(res => {
                if (res.error) {
                    throw (res.error);
                }
                dispatch(controlsFetchDataSuccess(res));
                return res;
            })
            .catch(() => dispatch(itemsHasErrored(true)));
    };
}
