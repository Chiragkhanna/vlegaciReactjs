import React, { Component } from "react";
import Step from "../../components/step";
import { withRouter } from 'react-router-dom'
import { connect } from 'react-redux';

class Run extends Component {
    navigateToPage = (e) => {
        e.preventDefault();
        this.props.history.push('/control');
    };
    render() {
        return (
            <section class="feature_area p_100">
                <div class="container">
                    <div class="row"><div class="blog_text"><a class="more_btn" href="#" onClick={this.navigateToPage}>Back</a> </div> </div>
                    <div class="row">
                        <Step />
                    </div>
                </div>
            </section>
        );
    }
}

export default Run;
