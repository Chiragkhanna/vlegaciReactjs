export const CONTROL_DATA_API_URL = 'http://localhost:3004/control';

export const RUN_DATA_API_URL = 'http://localhost:3004/Data';
