import React, { Component } from 'react'
import { bindActionCreators } from 'redux';
import ReactTable from 'react-table'
import 'react-table/react-table.css'
import { subComponent } from './controlTableSetup';
import { connect } from 'react-redux';
import { fetchControls } from './fetchControls';

// @ts-ignore
delete ReactTable.propTypes.ExpanderComponent

class ControlTable extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selected: {},
            selectAll: 0,
            error: null,
            isLoaded: false,
            initial_data: []
        }
        this.toggleRow = this.toggleRow.bind(this);
    }
    toggleRow(title) {
        const newSelected = Object.assign({}, this.state.selected);
        newSelected[title] = !this.state.selected[title];
        this.setState({
            selected: newSelected,
            selectAll: 2
        });
    }
    componentDidMount() {
        //this.ControlList();
        if (!this.props.controlList || !(this.props.controlList.length > 0)) {
            this.props.fetchData('http://localhost:3004/control');
        }

    }
    ControlList() {
        fetch('http://localhost:3004/control').then(res => { return res.json(); })
            .then(results => { this.setState({ initial_data: results, isLoaded: true }) })
            // Note: it's important to handle errors here
            // instead of a catch() block so that we don't swallow
            // exceptions from actual bugs in components.
            .catch((error) => {
                this.setState({
                    isLoaded: true,
                    error
                });
            });
    }

    render() {
        // const { initial_data } = this.state.initial_data;
        const { error, pending, controlList } = this.props;
        if (error) {
            return <div>Error: {error}</div>;
        } else if (pending) {
            return <div>Loading... {this.props.pending}</div>;
        } else {
            let defaultExpandedRows = {}; let columns = []
            if (controlList) {
                defaultExpandedRows = controlList.map((element, index) => { return { index: true } });
                columns = Object.keys(Object.assign({ "base": 1 }, controlList[0])).map((key, id) => {

                    if (key === "base")
                        return {
                            id: "checkbox",
                            accessor: "",
                            Cell: ({ original }) => {
                                return (
                                    <input
                                        type="checkbox"
                                        className="checkbox"
                                        checked={this.state.selected[original.Run] === true}
                                        onChange={() => this.toggleRow(original.Run)}
                                    />
                                );
                            },
                            Header: " ",
                            sortable: false,
                            width: 60
                        };
                    else {
                        let curWidth = controlList.reduce((prev, current) => (prev > current[key].length) ? prev : current[key].length);
                        return {
                            Header: key,
                            accessor: key,
                            minWidth: curWidth != undefined && curWidth > 20 ? 250 : 100
                        }
                    }
                });
            }

            return <ReactTable
                data={controlList}
                columns={columns}
                defaultExpanded={defaultExpandedRows}
                showPagination={false}
                minRows={1}
                className="-striped -highlight runTable"
                //SubComponent={subComponent}
                SubComponent={(v) => <div style={{ padding: '10px' }}>Hello {v.row._index}</div>}
            />
        }
    }
}
const mapStateToProps = (state) => {
    return {
        controlList: state.controlReducer.controlList,
        error: state.error,
        pending: state.pending
    };
};
// const mapDispatchToProps = (dispatch) => {
//     return {
//         fetchData: (url) => dispatch(fetchControls(url))
//     };
// };
const mapDispatchToProps = dispatch => bindActionCreators({
    fetchData: fetchControls
}, dispatch)
export default connect(mapStateToProps, mapDispatchToProps)(ControlTable);
//export default ControlTable;