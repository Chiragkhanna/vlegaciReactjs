import React, { Component } from "react";
import Step from "../../components/step";

class Run extends Component {
    render() {
        return (
            <section class="feature_area p_100">
                <div class="container">
                    <div class="row">

                        <Step />
                    </div>
                </div>
            </section>
        );
    }
}

export default Run;